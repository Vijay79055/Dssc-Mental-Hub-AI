import { ChatInterface } from "@/components/ChatInterface";
import { Heart, Shield, Sparkles } from "lucide-react";

const Index = () => {
  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-background to-secondary/20">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Heart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  Mahalingam College
                </h1>
                <p className="text-sm text-muted-foreground">Mental Wellness Hub</p>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                <span>Private & Secure</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary" />
                <span>AI-Powered Support</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Interface */}
      <main className="flex-1 overflow-hidden">
        <div className="container mx-auto h-full max-w-5xl">
          <ChatInterface />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/80 backdrop-blur-sm py-3">
        <div className="container mx-auto px-4">
          <p className="text-xs text-center text-muted-foreground">
            This is an AI assistant. For emergencies, please contact campus counseling services
            or call emergency helpline: <span className="font-semibold">1800-XXX-XXXX</span>
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
