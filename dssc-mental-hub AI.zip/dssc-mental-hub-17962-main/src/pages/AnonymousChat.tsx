
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { messageService, Message } from '@/services/messageService';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Send } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const AnonymousChat = () => {
  const { user, role } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      // Load messages
      const loadedMessages = messageService.getMessagesForUser(user, role as any);
      setMessages(loadedMessages);
    }
  }, [user, role]);

  useEffect(() => {
    // Scroll to the bottom when messages change
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!input.trim() || !user) return;

    // Send message
    const newMessage = messageService.sendMessage(input, user, 'student', isAnonymous);
    
    // Update local state
    setMessages(prev => [...prev, newMessage]);
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="flex flex-col h-[calc(100vh-5rem)] max-w-4xl mx-auto p-4">
      <Card className="flex-grow overflow-hidden flex flex-col">
        <CardHeader className="border-b">
          <CardTitle className="text-xl font-bold text-mentalcare-primary">
            Anonymous Messaging with Dr. Abinavu
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 flex-grow overflow-y-auto">
          {messages.length === 0 ? (
            <div className="flex h-full items-center justify-center text-gray-500">
              <p>Send a message to get started. Your identity will be hidden from the psychiatrist.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'student' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`${
                      msg.role === 'student' ? 'user-message' : 'bot-message'
                    } max-w-[80%]`}
                  >
                    <div className="mb-1 text-xs opacity-70">
                      {msg.role === 'student' ? 'You' : 'Dr. Abinavu'} • {formatDate(msg.timestamp)}
                    </div>
                    <p>{msg.content}</p>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          )}
        </CardContent>
        <div className="p-4 border-t">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center space-x-2">
              <Switch 
                id="anonymous-mode" 
                checked={isAnonymous} 
                onCheckedChange={setIsAnonymous} 
              />
              <Label htmlFor="anonymous-mode">Send anonymously</Label>
            </div>
          </div>
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your message to Dr. Abinavu..."
              className="flex-grow resize-none"
              rows={2}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim()}
              className="bg-mentalcare-primary hover:bg-mentalcare-secondary"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default AnonymousChat;
