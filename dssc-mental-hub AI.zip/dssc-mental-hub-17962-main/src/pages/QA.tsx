
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const mentalHealthFaqs = [
  {
    question: "How do I know if I need professional help with my mental health?",
    answer: "Consider seeking professional help if you experience persistent feelings of sadness or anxiety, significant changes in sleep or appetite, difficulty concentrating, withdrawal from friends or activities, or thoughts of self-harm. These symptoms lasting more than two weeks may indicate you could benefit from speaking with a mental health professional."
  },
  {
    question: "What's the difference between stress and anxiety?",
    answer: "Stress is typically a response to an external cause (like an exam or deadline) and subsides once the situation is resolved. Anxiety is a persistent feeling of worry that doesn't go away even in the absence of a stressor. While everyone experiences stress, anxiety that interferes with daily activities may require professional support."
  },
  {
    question: "How can I help a friend who seems depressed?",
    answer: "Start by listening without judgment and expressing concern. Encourage them to talk to a mental health professional and offer to help them find resources. Stay in touch and include them in activities, but respect their boundaries. Remember that you cannot fix their depression, but your support matters. If they mention thoughts of suicide, take it seriously and help them connect with immediate support."
  },
  {
    question: "What are some effective ways to manage exam anxiety?",
    answer: "Prepare well in advance, practice relaxation techniques like deep breathing, maintain a healthy sleep schedule, exercise regularly, limit caffeine, use positive self-talk, and break study sessions into manageable chunks. If anxiety becomes overwhelming despite these strategies, consider speaking with a counselor."
  },
  {
    question: "How can I improve my sleep quality as a student?",
    answer: "Maintain a consistent sleep schedule (even on weekends), create a relaxing bedtime routine, limit screen time before bed, avoid caffeine and heavy meals in the evening, keep your room cool and dark, and exercise regularly (but not too close to bedtime). If sleep problems persist, consult with a healthcare professional."
  },
  {
    question: "What is impostor syndrome and how can I deal with it?",
    answer: "Impostor syndrome involves persistent self-doubt and feeling like a fraud despite evidence of your competence. To manage it, acknowledge these feelings, talk to others (many experience this), focus on your achievements, accept that perfection isn't realistic, and reframe failure as a learning opportunity. Remember that feeling like an impostor doesn't mean you are one."
  }
];

const QA = () => {
  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl animate-fade-in">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-mentalcare-primary">Mental Health Q&A</CardTitle>
          <CardDescription>
            Common questions and expert answers about mental health for students
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {mentalHealthFaqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left font-medium">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-700">
                  <p className="py-2">{faq.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          
          <div className="mt-8 bg-gray-100 p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-2">Have a question not covered here?</h3>
            <p className="mb-4">You can ask Dr. Abinavu directly through the anonymous chat feature or use the AI chat assistant.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QA;
