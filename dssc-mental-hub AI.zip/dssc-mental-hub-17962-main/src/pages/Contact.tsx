
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mail, Globe, Key } from 'lucide-react';

const Contact = () => {
  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl animate-fade-in">
      <Card className="shadow-lg">
        <CardHeader className="bg-gradient-to-r from-mentalcare-primary to-mentalcare-secondary text-white">
          <CardTitle className="text-2xl font-bold">Contact Our Mental Health Professional</CardTitle>
          <CardDescription className="text-gray-100">
            Reach out directly to our certified psychiatrist
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="flex items-start gap-3">
                <div className="bg-mentalcare-primary rounded-full p-2 text-white mt-1">
                  <Mail className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Dr. Abinavu</h3>
                  <p className="text-gray-600 mb-1">Certified Psychiatrist</p>
                  <p className="text-gray-600 mb-1">
                    Email: <a href="mailto:abinavuabinavu@gmail.com" className="text-mentalcare-primary hover:underline">
                      abinavuabinavu@gmail.com
                    </a>
                  </p>
                  <p className="text-gray-600">
                    Phone: <a href="tel:9003989727" className="text-mentalcare-primary hover:underline">
                      9003989727
                    </a>
                  </p>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="font-semibold mb-2">Office Hours</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>Monday - Friday: 9:00 AM - 5:00 PM</li>
                  <li>Saturday: 10:00 AM - 2:00 PM</li>
                  <li>Sunday: Closed (Emergency contact only)</li>
                </ul>
              </div>
              
              <div className="flex items-center gap-3 border-t pt-4">
                <Globe className="h-5 w-5 text-mentalcare-primary" />
                <div>
                  <p className="text-gray-600">
                    For access to global mental health resources, visit our
                    <a href="/worldwide" className="text-mentalcare-primary hover:underline ml-1">
                      Worldwide Resources
                    </a> page.
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 border-t pt-4">
                <Key className="h-5 w-5 text-mentalcare-primary" />
                <div>
                  <p className="text-gray-600">
                    Need privacy? Use our
                    <a href="/anonymous" className="text-mentalcare-primary hover:underline mx-1">
                      Anonymous Chat
                    </a>
                    feature to communicate without revealing your identity.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-100 p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">Emergency Contact Information</h3>
              <p className="mb-4 text-gray-700">
                If you're experiencing a mental health emergency or having thoughts of self-harm:
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-mentalcare-primary">•</span>
                  <span>Call Dr. Abinavu's emergency line: <strong>9003989727</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-mentalcare-primary">•</span>
                  <span>National Mental Health Helpline: <strong>1800-599-0019</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-mentalcare-primary">•</span>
                  <span>Visit your nearest emergency room</span>
                </li>
              </ul>
              <Button className="w-full bg-mentalcare-primary hover:bg-mentalcare-secondary">
                <a href="tel:9003989727" className="w-full flex justify-center">
                  Call Dr. Abinavu Now
                </a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Contact;
