
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { messageService, Message } from '@/services/messageService';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Send } from 'lucide-react';

const Messages = () => {
  const { user, role } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      // Load messages for psychiatrist
      const loadedMessages = messageService.getMessagesForUser(user, 'psychiatrist');
      setMessages(loadedMessages);
      
      // Mark all as read
      loadedMessages.forEach(msg => {
        if (!msg.read) {
          messageService.markAsRead(msg.id);
        }
      });
    }
  }, [user]);

  useEffect(() => {
    // Scroll to the bottom when messages change
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!input.trim() || !user) return;

    // Send message as psychiatrist
    const newMessage = messageService.sendMessage(input, user, 'psychiatrist', false);
    
    // Update local state
    setMessages(prev => [...prev, newMessage]);
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const getSenderDisplay = (message: Message) => {
    if (message.role === 'psychiatrist') {
      return 'You (Dr. Abinavu)';
    } else if (message.isAnonymous) {
      return 'Anonymous Student';
    } else {
      return `Student: ${message.senderId}`;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-5rem)] max-w-4xl mx-auto p-4">
      <Card className="flex-grow overflow-hidden flex flex-col">
        <CardHeader className="border-b">
          <CardTitle className="text-xl font-bold text-mentalcare-primary">
            Student Messages
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 flex-grow overflow-y-auto">
          {messages.length === 0 ? (
            <div className="flex h-full items-center justify-center text-gray-500">
              <p>No messages yet. Students can send both regular and anonymous messages.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'psychiatrist' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`${
                      msg.role === 'psychiatrist' ? 'user-message' : 'bot-message'
                    } max-w-[80%]`}
                  >
                    <div className="mb-1 text-xs opacity-70">
                      {getSenderDisplay(msg)} • {formatDate(msg.timestamp)}
                    </div>
                    <p>{msg.content}</p>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          )}
        </CardContent>
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your response to students..."
              className="flex-grow resize-none"
              rows={2}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim()}
              className="bg-mentalcare-primary hover:bg-mentalcare-secondary"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Messages;
