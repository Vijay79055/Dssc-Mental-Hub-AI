
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { aiService } from '@/services/aiService';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Send } from 'lucide-react';

interface ChatMessage {
  role: 'user' | 'bot';
  content: string;
}

const Chat = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Add a welcome message when component mounts
    if (messages.length === 0) {
      setMessages([
        {
          role: 'bot',
          content: `Hello ${user}! I'm your mental health assistant. How can I help you today?`
        }
      ]);
    }
  }, [user, messages.length]);

  useEffect(() => {
    // Scroll to the bottom when messages change
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      // Get response from AI service
      const response = await aiService.sendMessage(input);
      
      // Add bot response
      setMessages(prev => [...prev, { role: 'bot', content: response }]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      setMessages(prev => [
        ...prev, 
        { 
          role: 'bot', 
          content: "I'm having trouble connecting right now. Please try again later or contact our psychiatrist directly." 
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-5rem)] max-w-4xl mx-auto p-4">
      <Card className="flex-grow overflow-hidden flex flex-col">
        <CardContent className="p-4 flex-grow overflow-y-auto">
          <div className="space-y-4">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`${
                    msg.role === 'user' ? 'user-message' : 'bot-message'
                  } max-w-[80%]`}
                >
                  <p>{msg.content}</p>
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
        </CardContent>
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your message..."
              className="flex-grow resize-none"
              rows={2}
              disabled={loading}
            />
            <Button
              onClick={handleSendMessage}
              disabled={loading || !input.trim()}
              className="bg-mentalcare-primary hover:bg-mentalcare-secondary"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          {loading && <p className="text-sm text-gray-500 mt-2">Getting response...</p>}
        </div>
      </Card>
    </div>
  );
};

export default Chat;
