
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Globe, Mail } from 'lucide-react';

const Worldwide = () => {
  const resources = {
    global: [
      {
        name: "World Health Organization (WHO) Mental Health",
        description: "Resources and information on mental health from the world's leading health organization.",
        url: "https://www.who.int/health-topics/mental-health"
      },
      {
        name: "International Association for Suicide Prevention",
        description: "Worldwide resources for suicide prevention and support.",
        url: "https://www.iasp.info/resources/"
      },
      {
        name: "Psychology Today International Therapist Directory",
        description: "Find mental health professionals across the globe.",
        url: "https://www.psychologytoday.com/intl/counsellors"
      }
    ],
    india: [
      {
        name: "NIMHANS",
        description: "National Institute of Mental Health and Neurosciences - India's premier mental health institution.",
        url: "https://nimhans.ac.in/"
      },
      {
        name: "AASRA",
        description: "24/7 Helpline for those feeling suicidal or in emotional distress.",
        phone: "91-9820466726",
        url: "http://www.aasra.info/"
      },
      {
        name: "The Live Love Laugh Foundation",
        description: "Foundation focused on reducing stigma around mental health in India.",
        url: "https://thelivelovelaughfoundation.org/"
      },
      {
        name: "iCALL",
        description: "Psychosocial helpline by TISS that offers counseling via telephone, email and chat.",
        phone: "91-9152987821",
        url: "https://icallhelpline.org/"
      }
    ],
    articles: [
      {
        title: "Cultural Considerations in Mental Health Treatment",
        source: "World Psychiatric Association",
        url: "https://www.wpanet.org/"
      },
      {
        title: "Student Mental Health in a Global Perspective",
        source: "International Journal of Mental Health Systems",
        url: "https://ijmhs.biomedcentral.com/"
      },
      {
        title: "Cross-Cultural Understanding of Mental Health",
        source: "World Federation for Mental Health",
        url: "https://wfmh.global/"
      }
    ]
  };

  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl animate-fade-in">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-mentalcare-primary" />
            <CardTitle className="text-2xl font-bold text-mentalcare-primary">Global Mental Health Resources</CardTitle>
          </div>
          <CardDescription>
            Access mental health resources and support from around the world
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="global">
            <TabsList className="mb-6">
              <TabsTrigger value="global">Global Resources</TabsTrigger>
              <TabsTrigger value="india">India Resources</TabsTrigger>
              <TabsTrigger value="articles">Research & Articles</TabsTrigger>
            </TabsList>
            
            <TabsContent value="global" className="space-y-4">
              {resources.global.map((resource, index) => (
                <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-semibold text-lg">{resource.name}</h3>
                  <p className="text-gray-600 mb-2">{resource.description}</p>
                  <a 
                    href={resource.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-mentalcare-primary hover:underline"
                  >
                    Visit Website
                  </a>
                </div>
              ))}
            </TabsContent>
            
            <TabsContent value="india" className="space-y-4">
              {resources.india.map((resource, index) => (
                <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-semibold text-lg">{resource.name}</h3>
                  <p className="text-gray-600 mb-2">{resource.description}</p>
                  {resource.phone && (
                    <p className="mb-2">Phone: <a href={`tel:${resource.phone}`} className="text-mentalcare-accent">{resource.phone}</a></p>
                  )}
                  <a 
                    href={resource.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-mentalcare-primary hover:underline"
                  >
                    Visit Website
                  </a>
                </div>
              ))}
            </TabsContent>
            
            <TabsContent value="articles" className="space-y-4">
              {resources.articles.map((article, index) => (
                <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-semibold text-lg">{article.title}</h3>
                  <p className="text-gray-600 mb-2">Source: {article.source}</p>
                  <a 
                    href={article.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-mentalcare-primary hover:underline"
                  >
                    Read More
                  </a>
                </div>
              ))}
            </TabsContent>
          </Tabs>
          
          <div className="mt-8 bg-gray-100 p-4 rounded-lg flex gap-4 items-start">
            <Mail className="h-5 w-5 text-mentalcare-primary mt-1" />
            <div>
              <h3 className="font-semibold text-lg">International Student Support</h3>
              <p className="text-gray-700">
                If you're an international student at Dhanalakshmi Srinivasan College and need culturally sensitive mental health support,
                Dr. Abinavu can provide guidance specific to your needs or help connect you with resources from your home country.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Worldwide;
