
// API endpoint for OpenRouter
const API_URL = "https://openrouter.ai/api/v1/chat/completions";
const API_KEY = "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";

export const aiService = {
  sendMessage: async (message: string): Promise<string> => {
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "deepseek/deepseek-r1:free",
          messages: [
            { 
              role: "system", 
              content: "You are a helpful mental health assistant for students at Dhanalakshmi Srinivasan College. Your responses should be supportive, empathetic, and informative. If someone appears to be in crisis, advise them to contact the psychiatrist Dr. Abinavu directly." 
            },
            { role: "user", content: message }
          ]
        })
      });

      if (!response.ok) {
        throw new Error("API request failed");
      }

      const data = await response.json();
      
      if (data.choices && data.choices[0]) {
        return data.choices[0].message.content;
      } else {
        return "I'm sorry, I couldn't process your message. Please try again.";
      }
    } catch (error) {
      console.error("Error with AI API:", error);
      return "I'm here to help, but I'm having trouble connecting right now. Please try again later.";
    }
  }
};
