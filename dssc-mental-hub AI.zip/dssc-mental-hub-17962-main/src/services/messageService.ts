
export interface Message {
  id: string;
  senderId: string;
  content: string;
  timestamp: number;
  isAnonymous: boolean;
  role: 'student' | 'psychiatrist';
  read: boolean;
}

// Mock storage for messages
let messages: Message[] = [];

// Load messages from localStorage if available
const loadMessages = () => {
  const savedMessages = localStorage.getItem('dssc_messages');
  if (savedMessages) {
    messages = JSON.parse(savedMessages);
  }
};

// Save messages to localStorage
const saveMessages = () => {
  localStorage.setItem('dssc_messages', JSON.stringify(messages));
};

// Initialize
loadMessages();

export const messageService = {
  // Get all messages for a user
  getMessagesForUser: (userId: string, role: 'student' | 'psychiatrist'): Message[] => {
    if (role === 'student') {
      // Students can only see their own messages
      return messages.filter(m => m.senderId === userId || (m.role === 'psychiatrist'));
    } else if (role === 'psychiatrist') {
      // Psychiatrists can see all messages
      return [...messages];
    }
    return [];
  },

  // Send a message
  sendMessage: (content: string, senderId: string, role: 'student' | 'psychiatrist', isAnonymous: boolean = false): Message => {
    const newMessage: Message = {
      id: Date.now().toString(),
      senderId,
      content,
      timestamp: Date.now(),
      isAnonymous,
      role,
      read: false
    };
    
    messages.push(newMessage);
    saveMessages();
    return newMessage;
  },

  // Mark message as read
  markAsRead: (messageId: string): void => {
    const message = messages.find(m => m.id === messageId);
    if (message) {
      message.read = true;
      saveMessages();
    }
  },

  // Get unread count for user
  getUnreadCount: (userId: string, role: 'student' | 'psychiatrist'): number => {
    if (role === 'student') {
      return messages.filter(m => m.role === 'psychiatrist' && !m.read).length;
    } else {
      return messages.filter(m => m.role === 'student' && !m.read).length;
    }
  }
};
