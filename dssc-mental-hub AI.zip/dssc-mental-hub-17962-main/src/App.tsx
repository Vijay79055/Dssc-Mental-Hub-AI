
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

// Pages
import Index from "./pages/Index";
import StudentLogin from "./pages/StudentLogin";
import PsychiatristLogin from "./pages/PsychiatristLogin";
import Chat from "./pages/Chat";
import AnonymousChat from "./pages/AnonymousChat";
import Messages from "./pages/Messages";
import QA from "./pages/QA";
import Worldwide from "./pages/Worldwide";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-grow bg-mentalcare-background">
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Index />} />
                <Route path="/login/student" element={<StudentLogin />} />
                <Route path="/login/psychiatrist" element={<PsychiatristLogin />} />
                <Route path="/contact" element={<Contact />} />
                
                {/* Protected Routes */}
                <Route path="/chat" element={
                  <ProtectedRoute>
                    <Chat />
                  </ProtectedRoute>
                } />
                <Route path="/anonymous" element={
                  <ProtectedRoute allowedRoles={['student']}>
                    <AnonymousChat />
                  </ProtectedRoute>
                } />
                <Route path="/messages" element={
                  <ProtectedRoute allowedRoles={['psychiatrist']}>
                    <Messages />
                  </ProtectedRoute>
                } />
                <Route path="/qa" element={
                  <ProtectedRoute>
                    <QA />
                  </ProtectedRoute>
                } />
                <Route path="/worldwide" element={
                  <ProtectedRoute>
                    <Worldwide />
                  </ProtectedRoute>
                } />
                
                {/* Catch-all Route */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
