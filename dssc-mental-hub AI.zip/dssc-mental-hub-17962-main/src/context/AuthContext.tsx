
import React, { createContext, useState, useContext, useEffect } from 'react';

type UserRole = 'student' | 'psychiatrist' | null;

interface AuthContextType {
  user: string | null;
  role: UserRole;
  isAuthenticated: boolean;
  login: (username: string, password: string, role: UserRole) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<string | null>(null);
  const [role, setRole] = useState<UserRole>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is already logged in
    const savedUser = localStorage.getItem('dssc_user');
    const savedRole = localStorage.getItem('dssc_role') as UserRole;
    
    if (savedUser && savedRole) {
      setUser(savedUser);
      setRole(savedRole);
      setIsAuthenticated(true);
    }
  }, []);

  const login = (username: string, password: string, role: UserRole) => {
    // Simple authentication logic
    // For student login
    if (role === 'student') {
      // In a real app, you would validate credentials against a database
      if (password.length >= 4) {
        setUser(username);
        setRole('student');
        setIsAuthenticated(true);
        localStorage.setItem('dssc_user', username);
        localStorage.setItem('dssc_role', 'student');
        return true;
      }
    }
    
    // For psychiatrist login
    if (role === 'psychiatrist') {
      // Simple validation - in a real app, use proper auth
      if (username === 'Abinavu' && password.length >= 4) {
        setUser(username);
        setRole('psychiatrist');
        setIsAuthenticated(true);
        localStorage.setItem('dssc_user', username);
        localStorage.setItem('dssc_role', 'psychiatrist');
        return true;
      }
    }
    
    return false;
  };

  const logout = () => {
    setUser(null);
    setRole(null);
    setIsAuthenticated(false);
    localStorage.removeItem('dssc_user');
    localStorage.removeItem('dssc_role');
  };

  const value = {
    user,
    role,
    isAuthenticated,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
