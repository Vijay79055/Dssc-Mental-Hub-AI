
import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { LogOut, User } from 'lucide-react';

const Navbar = () => {
  const { user, role, logout, isAuthenticated } = useAuth();

  return (
    <header className="bg-mentalcare-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div>
            <Link to="/" className="text-xl font-bold flex items-center">
              Dhanalakshmi Srinivasan Student Well Care
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-4">
            {isAuthenticated && (
              <>
                <Link to="/chat" className="hover:text-gray-200">Chat</Link>
                {role === 'psychiatrist' && (
                  <Link to="/messages" className="hover:text-gray-200">Messages</Link>
                )}
                {role === 'student' && (
                  <Link to="/anonymous" className="hover:text-gray-200">Anonymous Chat</Link>
                )}
                <Link to="/qa" className="hover:text-gray-200">Q&A</Link>
                <Link to="/worldwide" className="hover:text-gray-200">Worldwide</Link>
                <Link to="/contact" className="hover:text-gray-200">Contact</Link>
              </>
            )}
          </nav>
          
          <div className="flex items-center space-x-2">
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <span className="hidden md:inline-block">
                  <User className="inline-block h-4 w-4 mr-1" /> 
                  {user} ({role})
                </span>
                <Button 
                  variant="outline" 
                  onClick={logout} 
                  className="bg-white text-mentalcare-primary hover:bg-gray-100"
                >
                  <LogOut className="h-4 w-4 mr-1" /> Logout
                </Button>
              </div>
            ) : (
              <div className="flex space-x-2">
                <Link to="/login/student">
                  <Button variant="outline" className="bg-white text-mentalcare-primary hover:bg-gray-100">
                    Student Login
                  </Button>
                </Link>
                <Link to="/login/psychiatrist">
                  <Button variant="outline" className="bg-white text-mentalcare-primary hover:bg-gray-100">
                    Psychiatrist Login
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
